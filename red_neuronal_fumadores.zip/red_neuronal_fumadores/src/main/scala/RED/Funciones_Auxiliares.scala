package RED

import org.apache.hadoop.shaded.org.apache.commons.math3.optim.nonlinear.vector.Weight
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.util.CollectionAccumulator

import scala.math._
import java.time._
import java.time.format.DateTimeFormatter
//import scala.collection.IterableOnce.iterableOnceExtensionMethods
import scala.collection.mutable.ListBuffer
import scala.io.Source
import scala.util.Random

class Funciones_Auxiliares extends Serializable{

  // Función de activación ReLU
  def relu(x: Double): Double = Math.max(0, x)

  // Función de activación Sigmoide
  def sigmoid(x: Double): Double = 1.0 / (1.0 + Math.exp(-x))

  def signo_umbral(number: Double, umbral: Double): Double ={
    var resultado: Double = 0.5
    if (number < umbral){
      resultado = 0.0
    }else{
      resultado = 1.0
    }
    resultado
  }

  // Calcula wT*x(i) (Valor predicho para el dato x(i))
  def h(x: Array[Array[Double]], w: Array[Double], i: Int): Double = {
    var sum = 0.0
    for (j <- x(i).indices) {
      sum += x(i)(j) * w(j)
    }
    sum
  }

  def forwardProp(x: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    val z2 = Array.fill(nHidden)(0.0)

    // Paso de capa inicial a oculta
    for (j <- 0 until nHidden) {
      val weights1 = weights.slice(nInputs * j, nInputs * (j + 1))
      //println(s"longitud de x: ${x.length} - longitud de pesos: ${weights1.length}")
      var resultado = 0.0
      for (k <- 0 until nInputs) {
        resultado += x(k) * weights1(k)
      }
      z2(j) = tanh(resultado)
    }



    // Paso de capa oculta a la salida
    var z3 = 0.0
    val weights2 = weights.slice(nInputs * nHidden, weights.length)
    for (k <- 0 until nHidden) {
      z3 += z2(k) * weights2(k)
    }

    // No aplicamos la tangente hiperbólica en la capa de salida (función identidad)
    z3
  }

  def forwardPropClas(x: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    val z2 = Array.fill(nHidden)(0.0)

    // Paso de capa inicial a oculta
    for (j <- 0 until nHidden) {
      val weights1 = weights.slice(nInputs * j, nInputs * (j + 1))
      var resultado = 0.0
      for (k <- 0 until nInputs) {
        resultado += x(k) * weights1(k)
      }
      z2(j) = relu(resultado)
    }

    // Paso de capa oculta a la salida
    var z3 = 0.0
    val weights2 = weights.slice(nInputs * nHidden, weights.length)
    for (k <- 0 until nHidden) {
      z3 += z2(k) * weights2(k)
    }

    // Aplicamos la tangente hiperbólica en la capa de salida (función identidad)
    val z4 = sigmoid(z3)
    z4
  }

  def forwardPropClas_2_capas(x: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    val z2 = Array.fill(nHidden)(0.0)
    val z3 = Array.fill(nHidden)(0.0)

    // Paso de capa inicial a la primera capa oculta
    for (j <- 0 until nHidden) {
      val weights1 = weights.slice(nInputs * j, nInputs * (j + 1))
      var resultado = 0.0
      for (k <- 0 until nInputs) {
        resultado += x(k) * weights1(k)
      }
      //z2(j) = tanh(resultado)
      z2(j) = relu(resultado)
    }

    // Paso de la primera capa oculta a la segunda capa oculta
    val desfase = nInputs*nHidden
    for (j <- 0 until nHidden) {
      val weights2 = weights.slice(desfase + nHidden * j, desfase + nHidden * (j + 1))
      var resultado = 0.0
      for (k <- 0 until nHidden) {
        resultado += z2(k) * weights2(k)
      }
      //z3(j) = tanh(resultado)
      z3(j) = relu(resultado)
    }

    // Paso de capa oculta a la salida
    var z4 = 0.0
    val weights3 = weights.slice((nInputs + nHidden) * nHidden, weights.length)
    for (k <- 0 until nHidden) {
      z4 += z3(k) * weights3(k)
    }

    // Aplicamos la tangente hiperbólica en la capa de salida
    //val z5 = tanh(z4)
    //z5

    z4
  }

  def calculateAccuracy(yTrue: Array[Double], yPred: Array[Double]): Double = {
    require(yTrue.length == yPred.length, "Las listas deben tener la misma longitud")

    val totalSamples = yTrue.length
    val correctPredictions = yTrue.zip(yPred).count { case (trueLabel, predictedLabel) => trueLabel == predictedLabel }


    val resultado = correctPredictions.toDouble / totalSamples

    //println("resultado accuracy en calculateAccuracy: " + resultado)

    resultado

  }

  def binaryCrossEntropy(yTrue: Array[Double], yPred: Array[Double]): Double = {
    require(yTrue.length == yPred.length, "Las listas deben tener la misma longitud")

    val epsilon = 1e-15 // Pequeña constante para evitar divisiones por cero
    val clippedYPred = yPred.map(p => Math.max(epsilon, Math.min(1 - epsilon, p))) // Clip para evitar log(0) y log(1)

    val loss = -yTrue.zip(clippedYPred).map { case (trueLabel, predLabel) =>
      trueLabel * Math.log(predLabel) + (1 - trueLabel) * Math.log(1 - predLabel)
    }.sum

    loss
  }

  def calculateF1Score(yTrue: Array[Double], yPred: Array[Double]): Double = {
    require(yTrue.length == yPred.length, "Las listas deben tener la misma longitud")

    val totalSamples = yTrue.length

    // Calcular True Positives, False Positives y False Negatives
    val (tp, fp, fn) = yTrue.zip(yPred).foldLeft((0, 0, 0)) {
      case ((truePositives, falsePositives, falseNegatives), (trueLabel, predictedLabel)) =>
        if (trueLabel == 1.0 && predictedLabel == 1.0) {
          (truePositives + 1, falsePositives, falseNegatives)
        } else if (trueLabel == 0.0 && predictedLabel == 1.0) {
          (truePositives, falsePositives + 1, falseNegatives)
        } else if (trueLabel == 1.0 && predictedLabel == 0.0) {
          (truePositives, falsePositives, falseNegatives + 1)
        } else {
          (truePositives, falsePositives, falseNegatives)
        }
    }

    // Calcular Precision y Recall
    val precision = tp.toDouble / (tp + fp)
    val recall = tp.toDouble / (tp + fn)

    // Calcular F1-score
    val f1Score = 2 * (precision * recall) / (precision + recall)

    f1Score
  }

  def calculateAUCROC(yTrue: Array[Double], yPred: Array[Double]): Double = {
    require(yTrue.length == yPred.length, "Las listas deben tener la misma longitud")

    val sortedIndices = yTrue.indices.sortBy(i => yPred(i)).reverse

    var aucSum = 0.0
    var currentFP = 0
    var currentTP = 0
    var lastFP = 0
    var lastTP = 0

    for (i <- sortedIndices) {
      if (yTrue(i) == 1.0) {
        currentTP += 1
        aucSum += currentFP - lastFP + (currentFP - lastFP + 1) / 2.0
        lastTP = currentTP
      } else {
        currentFP += 1
        lastFP = currentFP
      }
    }

    val totalPositives = yTrue.count(_ == 1.0)
    val totalNegatives = yTrue.length - totalPositives

    val normalizedAUC = aucSum / (totalPositives * totalNegatives).toDouble

    normalizedAUC
  }


  def MSERed(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    val n_datos = x.length

    for (i <- 0 until n_datos){
      //val pred = forwardProp(x(i), weights, nInputs, nHidden)
      val pred = forwardPropClas(x(i), weights, nInputs, nHidden)
      resultado += math.pow(y(i) - pred, 2)
    }
    resultado /= n_datos
    resultado

  }

  def AccuracyRed(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int, umbral: Double): Double = {
    var resultado = 0.0
    val n_datos = x.length

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until n_datos) {
      //val pr = signum(forwardPropClas(x(i), weights, nInputs, nHidden))
      val pr = signo_umbral(forwardPropClas(x(i), weights, nInputs, nHidden), 0.5)
      //Si usamos una red con dos capas
      //val pr = signo_umbral(forwardPropClas_2_capas(x(i), weights, nInputs, nHidden), umbral)
      yPred = yPred :+ pr
    }
    resultado = 1.0 - calculateAccuracy(y, yPred)
    //resultado = calculateAccuracy(y, yPred)
    //println("resultado accuracy: " + resultado)
    resultado

  }

  def binaryEntropyRed(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    val n_datos = x.length

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until n_datos) {
      val pr = forwardPropClas(x(i), weights, nInputs, nHidden)
      yPred = yPred :+ pr
    }
    resultado = binaryCrossEntropy(y, yPred)
    resultado

  }

  def f1Red(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    val n_datos = x.length

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until n_datos) {
      val pr = signum(forwardPropClas(x(i), weights, nInputs, nHidden))
      yPred = yPred :+ pr
    }
    resultado = 1.0 - calculateF1Score(y, yPred)
    //println("resultado: " + resultado)
    resultado

  }

  def aucRed(x: Array[Array[Double]], y: Array[Double], weights: Array[Double], nInputs: Int, nHidden: Int): Double = {
    var resultado = 0.0
    val n_datos = x.length

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until n_datos) {
      val pr = signum(forwardPropClas(x(i), weights, nInputs, nHidden))
      yPred = yPred :+ pr
    }
    resultado = 1.0 - calculateAUCROC(y, yPred)
    //println("resultado: " + resultado)
    resultado

  }


  def convertToDayOfWeek(dates: List[String]): List[String] = {
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    dates.map { dateStr =>
      val date = LocalDate.parse(dateStr, formatter)
      val dayOfWeek = date.getDayOfWeek.toString
      dayOfWeek
    }
  }

  def separateHourMinute(hourColumn: List[String]): (List[String], List[String]) = {
    val (hours, minutes) = hourColumn.map { hourStr =>
      val parts = hourStr.split(":")
      (parts(0), parts(1))
    }.unzip

    (hours, minutes)
  }

  def encode[T](values: List[T]): List[List[Double]] = {
    val uniqueValues = values.distinct
    val numValues = uniqueValues.length
    val numSamples = values.length

    values.map { value =>
      val index = uniqueValues.indexOf(value)
      List.tabulate(numValues)(i => if (i == index) 1.0 else 0.0)
    }
  }

  def encodeFumador(preData: List[Array[String]]): List[Array[Double]]={
    //Tomar datos a procesar
    val hearingLeft = preData.map(_(7))
    val hearingRight = preData.map(_(8))
    val caries = preData.map(_(22))

    //Datos que no se van a procesar

    val dataAux: List[Array[String]] = preData.map { row =>
      row.slice(1, 7)
    }
    val dataAuxDouble: List[Array[Double]] = dataAux.map(row => row.map(_.toDouble))

    val dataAux2: List[Array[String]] = preData.map { row =>
      row.slice(9, 22)
    }
    val dataAuxDouble2: List[Array[Double]] = dataAux2.map(row => row.map(_.toDouble))

    //Transformar datos
    val oneHotHearingLeft = encode(hearingLeft)
    val oneHotHearingRight = encode(hearingRight)
    val oneHotCaries = encode(caries)

    //Unir las matrices
    val combinedMatrix1 = oneHotHearingLeft.zip(oneHotHearingRight).map { case (rowA, rowB) =>
      rowA ++ rowB
    }
    val combinedMatrix2 = combinedMatrix1.zip(oneHotCaries).map { case (rowA, rowB) =>
      rowA ++ rowB
    }

    val combinedMatrix2Array = combinedMatrix2.map(_.toArray)

    val data1 = combinedMatrix2Array.zip(dataAuxDouble).map { case (rowA, rowB) =>
      rowA ++ rowB
    }
    val data = data1.zip(dataAuxDouble2).map { case (rowA, rowB) =>
      rowA ++ rowB
    }

    data
  }

  //Genera un uniform entre -a y a
  def Uniform(a: Double, rand: Random): Double = {
    val num = rand.nextDouble() * 2 * a // genera un número aleatorio entre 0.0 y 2a
    val ret = num - a
    ret
  }

  def fitnessEval(x: Array[Array[Double]], y: Array[Double], particula_pesos: Array[Double], nInputs: Int, nHidden: Int): Array[Double] = {

    val nWeights: Int =nHidden*(nInputs + 1)
    //Voy a usar dos capas ocultas
    //val nWeights: Int =nHidden*(nInputs + nHidden + 1)

    if (particula_pesos == null) {
      println("El array de pesos es null")
      return Array.empty[Double]
    }

    val best_fit_local = particula_pesos(3 * nWeights)
    val weights = particula_pesos.slice(0, nWeights)
    //val fit = MSERed(x, y, weights, nInputs, nHidden)
    //val fit = AccuracyRed(x, y, weights, nInputs, nHidden, umbral)
    //val fit = f1Red(x, y, weights, nInputs, nHidden)
    //val fit = aucRed(x, y, weights, nInputs, nHidden)
    val fit = binaryEntropyRed(x, y, weights, nInputs, nHidden)

    //println("fit " + fit)

    if (fit < best_fit_local) {
      particula_pesos(3 * nWeights) = fit
      for (k <- 0 until nWeights) {
        particula_pesos(2 * nWeights + k) = weights(k)
      }

    }
    particula_pesos
  }

  def posEval(part: Array[Double], mpg: Array[Double], N: Int, rand: Random, W: Double, c_1: Double, c_2: Double, V_max: Double, pos_max: Double): Array[Double] = {
    // global ind (no es necesario en Scala)
    val velocidades = part.slice(N, 2 * N)
    val mpl = part.slice(2 * N, 3 * N)
    val r_1 = rand.nextDouble()
    val r_2 = rand.nextDouble()
    for (k <- 0 until N) {
      velocidades(k) = W * velocidades(k) + c_1 * r_1 * (mpl(k) - part(k)) + c_2 * r_2 * (mpg(k) - part(k))
      if (velocidades(k) > V_max) {
        velocidades(k) = V_max
      } else if (velocidades(k) < -V_max) {
        velocidades(k) = -V_max
      }
      part(k) = part(k) + velocidades(k)
      if (part(k) > pos_max ){
        part(k) = pos_max
      } else if (part(k) < -pos_max){
        part(k) = -pos_max
      }
      part(N + k) = velocidades(k)
    }
    part
  }

  def modifyAccum(part: Array[Double], N: Int, local_accum_pos: CollectionAccumulator[Array[Double]], local_accum_fit: CollectionAccumulator[Double]): Unit = {
    local_accum_pos.add((part.slice(2 * N, 3 * N)))
    local_accum_fit.add(part(3 * N))
  }

  // Convertir el Array[Array[Double]] a un ListBuffer[Array[Double]]
  def toListBuffer(arrayArray: Array[Array[Double]]): ListBuffer[Array[Double]] = {
    val listBuffer: ListBuffer[Array[Double]] = ListBuffer.empty[Array[Double]]

    // Recorrer cada subarray en el Array[Array[Double]] y convertirlo a un List[Double]
    for (subArray <- arrayArray) {
      val list: List[Double] = subArray.toList
      // Agregar el List[Double] al ListBuffer[Array[Double]]
      listBuffer += list.toArray
    }

    listBuffer
  }

  def accuracyOfDataset(archivo_val: String, weights: Array[Double], nInputs: Int, nHidden: Int, takeRows: Boolean, numRowsToKeep: Int): Double={

    var dataRows = Source.fromFile(archivo_val).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dataListString: List[Array[String]] = dataRows.map(_.take(68))
    //val dataTest: List[Array[Double]] = dataListStringTest.map(_.map(_.toDouble))
    var valorStringTest = dataRows.map(_(68))
    var valor: List[Double] = valorStringTest.map {
      case "0" => 0.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    //var data = encodeFumador(dataListString)

    var data = dataListString.map(_.map(_.toDouble))

    if (takeRows) {
      data = data.take(numRowsToKeep)
      valor = valor.take(numRowsToKeep)
    }

    val x = data.toArray
    val y = valor.toArray

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until x.length) {
      val pr = signo_umbral(forwardPropClas(x(i), weights, nInputs, nHidden), 0.5)
      yPred = yPred :+ pr
    }

    val resultado = 1.0 - calculateAccuracy(y, yPred)
    //val resultado = calculateAccuracy(y, yPred)
    resultado
  }

  def f1OfDataset(archivo_val: String, weights: Array[Double], nInputs: Int, nHidden: Int): Double = {

    var dataRows = Source.fromFile(archivo_val).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dataListString: List[Array[String]] = dataRows.map(_.take(68))
    //val dataTest: List[Array[Double]] = dataListStringTest.map(_.map(_.toDouble))
    var valorStringTest = dataRows.map(_(68))
    val valor: List[Double] = valorStringTest.map {
      case "0" => 0.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    val data = encodeFumador(dataListString)

    val x = data.toArray
    val y = valor.toArray

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until x.length) {
      val pr = signum(forwardPropClas(x(i), weights, nInputs, nHidden))
      yPred = yPred :+ pr
    }

    println("Cantidad de unos predichos: ")
    val unosReales = y.count(_ == 1)
    val unosPredichos = yPred.count(_ == 1)
    println(s"La cantidad de unos reales es: $unosReales")
    println(s"La cantidad de unos predichos es: $unosPredichos")

    val resultado = 1.0 - calculateF1Score(y, yPred)
    resultado
  }

  def aucOfDataset(archivo_val: String, weights: Array[Double], nInputs: Int, nHidden: Int): Double = {

    var dataRows = Source.fromFile(archivo_val).getLines.drop(1).filter { line =>
      val cols = line.split(",").map(_.trim)
      cols.forall(_.nonEmpty) // Filtra las filas con valores no vacíos
    }.toList.map { line =>
      val cols = line.split(",").map(_.trim)
      cols
    }
    val dataListString: List[Array[String]] = dataRows.map(_.take(23))
    val data: List[Array[Double]] = dataListString.map(_.map(_.toDouble))
    var valorString = dataRows.map(_(23))
    val valor: List[Double] = valorString.map {
      case "0" => 0.0
      case "1" => 1.0
      case _ => throw new IllegalArgumentException("Valor no válido en la lista")
    }

    val x = data.toArray
    val y = valor.toArray

    var yPred: Array[Double] = Array.emptyDoubleArray
    for (i <- 0 until x.length) {
      val pr = signum(forwardPropClas(x(i), weights, nInputs, nHidden))
      yPred = yPred :+ pr
    }

    val resultado = 1.0 - calculateAUCROC(y, yPred)
    resultado
  }


}
